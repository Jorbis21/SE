/*****************************************************************************
* Filename:          C:\Users\marti\OneDrive\Documentos\4\proyectFinal\SE/drivers/motor_hw_v1_00_a/src/motor_hw.c
* Version:           1.00.a
* Description:       motor_hw Driver Source File
* Date:              Sat Dec 16 18:23:12 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "motor_hw.h"

/************************** Function Definitions ***************************/

