/*****************************************************************************
* Filename:          C:\Users\marti\OneDrive\Documentos\4\proyectFinal\SE/drivers/motor_v1_00_a/src/motor.c
* Version:           1.00.a
* Description:       motor Driver Source File
* Date:              Sat Dec 16 18:02:21 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "motor.h"

/************************** Function Definitions ***************************/

