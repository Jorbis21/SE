/*****************************************************************************
* Filename:          C:\Users\marti\OneDrive\Documentos\4\proyectFinal\SE/drivers/banner_v1_00_a/src/banner.c
* Version:           1.00.a
* Description:       banner Driver Source File
* Date:              Wed Dec 13 10:29:44 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "banner.h"

/************************** Function Definitions ***************************/

