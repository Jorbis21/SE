/*****************************************************************************
* Filename:          C:\Users\marti\OneDrive\Documentos\4\proyectFinal\SE/drivers/altavoz_v1_00_a/src/altavoz.c
* Version:           1.00.a
* Description:       altavoz Driver Source File
* Date:              Sat Dec 16 12:14:53 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "altavoz.h"

/************************** Function Definitions ***************************/

