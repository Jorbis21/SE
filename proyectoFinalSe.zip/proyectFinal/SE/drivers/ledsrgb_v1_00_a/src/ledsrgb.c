/*****************************************************************************
* Filename:          C:\Users\marti\OneDrive\Documentos\4\proyectFinal\SE/drivers/ledsrgb_v1_00_a/src/ledsrgb.c
* Version:           1.00.a
* Description:       ledsrgb Driver Source File
* Date:              Thu Dec 14 10:46:54 2023 (by Create and Import Peripheral Wizard)
*****************************************************************************/


/***************************** Include Files *******************************/

#include "ledsrgb.h"

/************************** Function Definitions ***************************/

